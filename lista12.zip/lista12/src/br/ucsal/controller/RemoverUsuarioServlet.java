package br.ucsal.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.repository.config.DatabaseConfig;

@WebServlet("/removerUsuarioServlet")
public class RemoverUsuarioServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String login = request.getParameter("login");

		// Remover o usuário do banco de dados
		if (removerUsuario(login)) {
			response.getWriter().println("Usuário removido com sucesso!");
		} else {
			response.getWriter().println("Erro ao remover o usuário.");
		}
	}

	private boolean removerUsuario(String login) {
	    
		try (Connection conn = DatabaseConfig.getConnection();
	         PreparedStatement stmt = conn.prepareStatement("DELETE FROM USUARIO WHERE login = ?")) {
	        stmt.setString(1, login);
	        
	        int rowsAffected = stmt.executeUpdate();
	        
	        return rowsAffected > 0; // Retorna true se a remoção afetou pelo menos uma linha
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}

}