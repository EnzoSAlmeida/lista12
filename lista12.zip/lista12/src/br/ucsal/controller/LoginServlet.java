package br.ucsal.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;

import br.ucsal.repository.config.DatabaseConfig;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   
		String login = request.getParameter("login");
	    String senha = request.getParameter("senha");
	    
	    // Verificar login e senha no banco de dados
	    if (verificarCredenciais(login, senha)) {
	        // Login bem-sucedido
	        response.getWriter().println("Login bem-sucedido!");
	    } else {
	        // Login falhou
	        response.getWriter().println("Login falhou! Verifique suas credenciais.");
	    }
	}

	private boolean verificarCredenciais(String login, String senha) {
	    try (Connection conn = DatabaseConfig.getConnection();
	         PreparedStatement stmt = conn.prepareStatement("SELECT senha FROM USUARIO WHERE login = ?")) {
	        stmt.setString(1, login);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                String senhaArmazenada = rs.getString("senha");
	                String senhaCriptografada = DigestUtils.md5Hex(senha);
	                return senhaCriptografada.equals(senhaArmazenada);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
}