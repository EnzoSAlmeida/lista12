package br.ucsal.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.model.Usuario;
import br.ucsal.repository.config.DatabaseConfig;

@WebServlet("/listaUsuariosServlet")
public class ListaUsuariosServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setAttribute("usuarios", obterUsuarios());
		request.getRequestDispatcher("listaUsuarios.jsp").forward(request, response);
	}

	private List<Usuario> obterUsuarios() {

		List<Usuario> usuarios = new ArrayList<>();

		try (Connection conn = DatabaseConfig.getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT * FROM USUARIO");
				ResultSet rs = stmt.executeQuery()) {
			while (rs.next()) {
				String login = rs.getString("login");
				String nome = rs.getString("nome");
				String email = rs.getString("email");

				Usuario usuario = new Usuario(login, nome, email);
				usuarios.add(usuario);
				System.out.println("usuario listado: login:"+usuarios.get(0).getLogin()+" email:"+usuarios.get(0).getEmail());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return usuarios;
	}
}