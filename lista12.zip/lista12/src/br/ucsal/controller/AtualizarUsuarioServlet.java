package br.ucsal.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.repository.config.DatabaseConfig;

@WebServlet("/atualizarUsuarioServlet")
public class AtualizarUsuarioServlet extends HttpServlet {
   
	private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     
    	String login = request.getParameter("login");
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");

        // Atualizar os dados do usuário no banco de dados
        if (atualizarUsuario(login, nome, email)) {
            response.getWriter().println("Usuário atualizado com sucesso!");
        } else {
            response.getWriter().println("Erro ao atualizar o usuário.");
        }
    }

    private boolean atualizarUsuario(String login, String nome, String email)  {
       
    	try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE USUARIO SET nome = ?, email = ? WHERE login = ?")) {
            stmt.setString(1, nome);
            stmt.setString(2, email);
            stmt.setString(3, login);
            
            int rowsAffected = stmt.executeUpdate();
            
            return rowsAffected > 0; // Retorna true se a atualização afetou pelo menos uma linha
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
