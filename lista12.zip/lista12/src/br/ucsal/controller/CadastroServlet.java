package br.ucsal.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;

import br.ucsal.repository.config.DatabaseConfig;

@WebServlet("/cadastroServlet")
public class CadastroServlet extends HttpServlet {
   
	private static final long serialVersionUID = 1L;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
    	String login = request.getParameter("login");
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String confirmarEmail = request.getParameter("confirmarEmail");
        String senha = request.getParameter("senha");
        String confirmarSenha = request.getParameter("confirmarSenha");

        // Validações
        if (!email.equals(confirmarEmail)) {
            response.getWriter().println("Os emails não coincidem!");
            return;
        }

        if (!senha.equals(confirmarSenha)) {
            response.getWriter().println("As senhas não coincidem!");
            return;
        }

        if (senha.equals(login)) {
            response.getWriter().println("A senha não pode ser igual ao login!");
            return;
        }

        if (senha.length() < 4 || senha.length() > 8) {
            response.getWriter().println("A senha deve ter entre 4 e 8 caracteres!");
            return;
        }

        if (verificarLoginExistente(login)) {
            response.getWriter().println("O login já existe!");
            return;
        }

        if (inserirUsuario(login, nome, email, senha)) {
            response.getWriter().println("Usuário cadastrado com sucesso!");
        } else {
            response.getWriter().println("Erro ao cadastrar o usuário.");
        }
    }

    private boolean verificarLoginExistente(String login)  {
        
    	try (Connection conn = DatabaseConfig.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT login FROM USUARIO WHERE login = ?")) {
            stmt.setString(1, login);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean inserirUsuario(String login, String nome, String email, String senha)  {
       
    	 String senhaCriptografada = DigestUtils.md5Hex(senha);
    	
    	try (Connection conn = DatabaseConfig.getConnection();
                PreparedStatement stmt = conn.prepareStatement("INSERT INTO USUARIO (login, senha, nome, email) VALUES (?, ?, ?, ?)")) {
            stmt.setString(1, login);
            stmt.setString(2, senhaCriptografada);
            stmt.setString(3, nome);
            stmt.setString(4, email);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}